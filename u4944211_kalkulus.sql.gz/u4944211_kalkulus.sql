-- MySQL dump 10.13  Distrib 5.6.37, for Linux (x86_64)
--
-- Host: localhost    Database: u4944211_kalkulus
-- ------------------------------------------------------
-- Server version	5.6.37

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `peserta`
--

DROP TABLE IF EXISTS `peserta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `peserta` (
  `nomor_polis` bigint(20) NOT NULL AUTO_INCREMENT,
  `nama` varchar(20) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `kanker` varchar(6) NOT NULL,
  `jantung` varchar(6) NOT NULL,
  `diabet` varchar(6) NOT NULL,
  `hutang` bigint(20) NOT NULL,
  `pekerjaan` varchar(20) NOT NULL,
  `nama_pekerjaan` varchar(20) NOT NULL,
  `gaji` bigint(20) NOT NULL,
  `hobi` varchar(20) NOT NULL,
  `nama_hobi` varchar(20) NOT NULL,
  `olahraga` varchar(20) NOT NULL,
  `nama_olahraga` varchar(20) NOT NULL,
  `menikah` varchar(6) NOT NULL,
  `rumah` varchar(5) NOT NULL,
  `jumlah_anak` int(2) NOT NULL,
  PRIMARY KEY (`nomor_polis`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `peserta`
--

LOCK TABLES `peserta` WRITE;
/*!40000 ALTER TABLE `peserta` DISABLE KEYS */;
INSERT INTO `peserta` (`nomor_polis`, `nama`, `tanggal_lahir`, `kanker`, `jantung`, `diabet`, `hutang`, `pekerjaan`, `nama_pekerjaan`, `gaji`, `hobi`, `nama_hobi`, `olahraga`, `nama_olahraga`, `menikah`, `rumah`, `jumlah_anak`) VALUES (1,'John cantoso','1998-08-12','20','0','0',500000,'6','Direktur',3000000000,'0','Lari','6','Sepak Bola','6','5',2),(2,'Agus Sudarmo','1998-08-12','0','0','0',500000,'6','Direktur',3000000,'0','Lari','6','Sepak Bola','6','5',2),(3,'Agus Sudarmo','1998-08-12','0','0','0',500000,'6','Direktur',3000000,'15','Lari','15','Sepak Bola','6','5',2),(4,'Agus Sudarmo','1998-08-12','0','0','0',500000,'6','Direktur',300000,'15','Lari','15','Sepak Bola','6','5',2),(5,'Agus Sudarmo','1998-08-12','0','0','0',500000,'6','Direktur',300000000,'15','Lari','15','Sepak Bola','6','5',2),(6,'Udin seduinia','1997-12-04','20','0','0',5000,'6','-',5000000,'6','-','6','-','6','0',2),(7,'Udin seduinia','1997-12-04','20','15','20',5000,'6','-',5000000,'6','-','6','-','6','0',2),(8,'Udin seduinia','1997-12-04','20','15','20',5000,'6','-',5000000,'6','-','6','-','6','0',2),(9,'Udin seduinia','1997-12-04','20','15','20',5000,'6','-',5000000,'6','-','6','-','6','0',2),(10,'Achmad yuliyanto fir','1998-07-08','0','0','0',0,'0','-',0,'6','Futsal','6','Lari','0','5',0),(11,'Hendrik','1996-09-03','0','0','20',0,'15','Kuli bangunan',2500000,'6','Membaca','6','Lari','0','5',0),(12,'Fandi','1998-06-26','20','15','0',0,'6','Coding',0,'15','Coding','6','Sit up','0','5',0),(13,'Faqih auliaurrahman','1998-09-03','0','0','0',0,'6','Boss',25000000,'0','-','0','-','0','5',0),(14,'John teee','1983-09-29','20','0','0',56000,'6','Guru',1200000,'6','Memancing','6','Sepak bola','6','5',2),(15,'Andri','1998-09-29','0','0','0',0,'6','Guru',4000000,'15','Skyboard','6','Lari','0','5',0),(16,'A','2017-09-18','20','15','20',200000,'6','Y',50000000,'0','0','6','H','6','5',2),(17,'Henrico Verdiansyah ','1997-12-22','0','0','0',2000000,'15','Ngoding',500000000,'15','Traveling','15','GYM','6','5',2),(18,'toha','2017-09-15','0','0','0',0,'0','nganggur',10000,'0','nganggur','0','nganggur','0','5',5),(19,'Sensor','1560-10-09','0','0','0',0,'15','Kerja lah',0,'15','Kepo','15','Kepo mulu ah','0','5',0),(20,'160535601721','2017-09-03','0','0','0',0,'6','Boss',100,'6','Ball','6','Joging','0','0',0),(21,'Jwjajaja','2017-10-04','0','0','0',333,'15','Gshshshs',33,'6','Yahaa','6','Bshs','0','5',0),(22,'','0000-00-00','','','',0,'','',0,'','','','','','',0);
/*!40000 ALTER TABLE `peserta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'u4944211_kalkulus'
--

--
-- Dumping routines for database 'u4944211_kalkulus'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-10-15 15:32:29
